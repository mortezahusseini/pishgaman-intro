import sidr from '../src/js/sidr';

describe('sidr.js', () => {
    var s = {
        sidr
    };

    delete s.sidr;
});
