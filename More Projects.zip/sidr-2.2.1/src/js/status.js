var sidrStatus = {
  moving: false,
  opened: false
};

export default sidrStatus;
